
/*
 * Carrot2 project.
 *
 * Copyright (C) 2011, Vittal Aithal <opensource@cognidox.com>
 * All rights reserved.
 *
 * Refer to the full license file "carrot2.LICENSE"
 * in the root folder of the repository checkout or at:
 * http://www.carrot2.org/carrot2.LICENSE
 */

package org.carrot2.source.opensearch;

import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import com.sun.syndication.fetcher.impl.HttpClientFeedFetcher;

/**
 * A {@link HttpClientFeedFetcher.CredentialSupplier} that always returns
 * a given username and password credentials pair.
 */
public class OpenSearchBasicCredentialsSupplier implements HttpClientFeedFetcher.CredentialSupplier
{
    /** The username for basic authentication */
    private String username;

    /** The password for basic authentication */
    private String password;

    /**
     * Construct the credentials supplier with the username and password
     *
     * @param user the username to use for this supplier
     * @param pass the password to use for this supplier
     */
    public OpenSearchBasicCredentialsSupplier(String user, String pass)
    {
        username = user;
        password = pass;
    }

    /**
     * Return the credentials
     */
    public Credentials getCredentials(String realm, String host) 
    {
        return new UsernamePasswordCredentials(username, password);
    }
}

