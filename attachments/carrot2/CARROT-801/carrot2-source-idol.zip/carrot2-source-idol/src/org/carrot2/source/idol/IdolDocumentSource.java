
/*
 * Carrot2 project.
 *
 * Copyright (C) 2002-2010, Dawid Weiss, Stanisław Osiński.
 * All rights reserved.
 *
 * Refer to the full license file "carrot2.LICENSE"
 * in the root folder of the repository checkout or at:
 * http://www.carrot2.org/carrot2.LICENSE
 */

package org.carrot2.source.idol;

import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.lang.StringEscapeUtils;
import org.carrot2.core.Document;
import org.carrot2.core.IDocumentSource;
import org.carrot2.core.ProcessingException;
import org.carrot2.core.attribute.Init;
import org.carrot2.core.attribute.Processing;
import org.carrot2.source.MultipageSearchEngine;
import org.carrot2.source.MultipageSearchEngineMetadata;
import org.carrot2.source.SearchEngineResponse;
import org.carrot2.util.StringUtils;
import org.carrot2.util.attribute.Attribute;
import org.carrot2.util.attribute.Bindable;
import org.carrot2.util.attribute.Input;
import org.carrot2.util.attribute.Required;
import org.carrot2.util.attribute.constraint.IntRange;
import org.slf4j.Logger;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.fetcher.FeedFetcher;
import com.sun.syndication.fetcher.impl.HttpURLFeedFetcher;

/**
 * A {@link IDocumentSource} fetching {@link Document}s (search results) from an
 * IDOL Search Engine.
 * <p>
 * Based on code donated by Julien Nioche.
 * Autonomy IDOL support contributed by James Sealey.
 * 
 */
@Bindable(prefix = "IdolDocumentSource")
public class IdolDocumentSource extends MultipageSearchEngine
{	
    /** Logger for this class. */
    final static Logger logger = org.slf4j.LoggerFactory.getLogger(IdolDocumentSource.class);

    /**
     * Maximum concurrent threads from all instances of this component.
     */
    private static final int MAX_CONCURRENT_THREADS = 10;
        
    /**
     * URL of the IDOL Server
     * 
     * @label IDOL Server Address
     * @level Advanced
     * @group Service
     */
    @Input
    @Processing
    @Init
    @Attribute
    @Required
    public String idolServerName;
    
    /**
     * IDOL Server Port
     * 
     * @label IDOL Server Port
     * @level Advanced
     * @group Service
     */
    @Input
    @Processing
    @Init
    @Attribute
    @Required
    public int idolServerPort;

    /**
     * IDOL XSL Template Name. The Reference of an IDOL XSL template that outputs the results in OpenSearch format
     * 
     * @label IDOL XSL Template Name
     * @level Advanced
     * @group Service
     */
    @Input
    @Processing
    @Init
    @Attribute
    @Required
    public String xslTemplateName;
    
    /**
     * Any other search attributes (separated by &amp;) from the Autonomy Query Search API's
     * Ensure all the attributes are entered to satisfy XSL that will be applied
     * 
     * @label Other IDOLSearch Attributes 
     * @level Advanced
     * @group Service
     */
    @Input
    @Processing
    @Init
    @Attribute
    public String otherSearchAttributes;
    
    /**
     * Results per page. The number of results per page the document source will expect
     * the feed to return.
     * 
     * @label Results per page
     * @level Advanced
     * @group Service
     */
    @Input
    @Processing
    @Init
    @Attribute
    @Required
    @IntRange(min = 1)
    public int resultsPerPage = 50;

    /**
     * Minimum IDOL Score. The minimum score of the results returned by IDOL. 
     * 
     * @label Minimum Score
     * @level Basic
     * @group Service
     */
    @Input
    @Processing
    @Init
    @Attribute
    @IntRange(min = 1)
    public int minScore = 50;
    
    /**
     * Maximum number of results. The maximum number of results the document source can
     * deliver.
     * 
     * @label Maximum results
     * @level Basic
     * @group Service
     */
    @Input
    @Processing
    @Init
    @Attribute
    @IntRange(min = 1)
    public int maximumResults = 100;
    
    /**
     * User agent header. The contents of the User-Agent HTTP header to use when making
     * requests to the feed URL. If empty or <code>null</code> value is provided,
     * the following User-Agent will be sent: <code>Rome Client (http://tinyurl.com/64t5n) 
     * Ver: UNKNOWN</code>.
     * 
     * @label User agent
     * @level Advanced
     * @group Service
     */
    @Input
    @Init
    @Processing
    @Attribute
    public String userAgent = null;
       
        
        /**
         * Search engine metadata create upon initialization.
         */
        private MultipageSearchEngineMetadata metadata;
       

        /** Fetcher for OpenSearch feed. */
        private FeedFetcher feedFetcher;

        @Override
        public void beforeProcessing()
        {         
            
            if (resultsPerPage == 0)
            {
                throw new ProcessingException("resultsPerPage must be set");
            }

            this.metadata = new MultipageSearchEngineMetadata(resultsPerPage, maximumResults,
                false);
            this.feedFetcher = new HttpURLFeedFetcher();
            if (org.apache.commons.lang.StringUtils.isNotBlank(this.userAgent))
            {
                this.feedFetcher.setUserAgent(this.userAgent);
            }
            
        }

        @Override
        public void process() throws ProcessingException
        {
            super.process(metadata,
                getSharedExecutor(MAX_CONCURRENT_THREADS, this.getClass()));
        }

        @Override
        protected Callable<SearchEngineResponse> createFetcher(final SearchRange bucket)
        {
            return new SearchEngineResponseCallable()
            {
                @SuppressWarnings("rawtypes")
                public SearchEngineResponse search() throws Exception
                {                  
					final String url = getURL();
                    //final String url = urlExtension.toString();                    
                    
                    logger.debug("Fetching URL: " + url);

                    /*
                     * TODO: Rome fetcher uses SUN's HttpClient and opens a persistent HTTP
                     * connection (background thread that keeps reference to the class
                     * loader). This causes minor memory leaks when reloading Web
                     * applications. Consider: 1) patching rome fetcher sources and adding
                     * Connection: close to request headers, 2) using Apache HttpClient, 3)
                     * using manual fetch of the syndication feed.
                     */
                    final SyndFeed feed = feedFetcher.retrieveFeed(new URL(url));
                    final SearchEngineResponse response = new SearchEngineResponse();

                    // The documentation does not mention that null value can be returned
                    // but we've seen a NPE here:
                    // http://builds.carrot2.org/browse/C2HEAD-SOURCES-4.
                    if (feed != null)
                    {
                        final List entries = feed.getEntries();
                        for (Iterator it = entries.iterator(); it.hasNext();)
                        {
                            final SyndEntry entry = (SyndEntry) it.next();
                            final Document document = new Document();

                            document.setField(Document.TITLE, clean(entry.getTitle()));
                            document.setField(Document.SUMMARY, clean(entry.getDescription()
                                .getValue()));
                            document.setField(Document.CONTENT_URL, entry.getLink());

                            response.results.add(document);
                        }
                    }

                    return response;
                }
            };
        }
        
        //Set the URL string using the Autonomy connection
        private String getURL()
        {
        	//Set stringbuilder to create the url string
    		StringBuilder url = new StringBuilder();
    		
    		//Append Server Address
    		url.append("http://");
    		url.append(this.idolServerName);
    		url.append(":");
    		url.append(this.idolServerPort);
    		
    		//build query parameters
    		url.append("/action=Query&");
    		url.append("Text=" + query + "&");
    		url.append("MinScore=" + this.minScore + "&");
    		url.append("maxresults=" + this.maximumResults + "&");
    		url.append("template=" + this.xslTemplateName + "&");
    		url.append(this.otherSearchAttributes);
    		
    		//Add the security token if the username has been set
    		if (userName != null)
			{
    			String securityToken = getSecurityToken();
    			if (securityToken != "")
    			{
    				url.append("&SecurityInfo=" + securityToken);
    			}
			}		
    		
    		//return the URL to an IDOL OPEN Search results page
			return url.toString();
        	
        }
        //get the security token using the username
        protected String getSecurityToken()
    	{
    		String rtn="";
    		try
    		{
    			String url = "http://" + this.idolServerName + ":" + this.idolServerPort + "/" + "action=userread&username=" + userName + "&securityinfo=true";
    			
    	        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    	        DocumentBuilder db = dbf.newDocumentBuilder();
    	        org.w3c.dom.Document doc = db.parse(new URL(url).openStream());	        
    	        rtn = URLEncoder.encode(GettingText(doc),"UTF-8");
    		}
    		catch (Exception e){}
            return rtn;
        }
    	
        //extract the token from the XML document
        public String GettingText(org.w3c.dom.Document document) {
           String rtn = "";
        	Element e = document.getDocumentElement();
            NodeList nodeList = e.getElementsByTagName("responsedata");
            for (int temp = 0; temp < nodeList.getLength(); temp++) {
            	 
                Node nNode = nodeList.item(temp);	    
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {      
                   Element eElement = (Element) nNode;      
                   rtn = getTagValue("autn:securityinfo",eElement);
          
                 }
            }
            return rtn;
        }
        
        //get the tag value
        private static String getTagValue(String sTag, Element eElement){
                NodeList nlList= eElement.getElementsByTagName(sTag).item(0).getChildNodes();
                Node nValue = (Node) nlList.item(0); 
             
                return nValue.getNodeValue();    
             }
         
        
        private String clean(String string)
        {
            return StringUtils.removeHtmlTags(StringEscapeUtils.unescapeHtml(string));
        }
    }
