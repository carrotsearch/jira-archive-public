
/*
 * Carrot2 project.
 *
 * Copyright (C) 2002-2011, Dawid Weiss, Stanisław Osiński.
 * All rights reserved.
 *
 * Refer to the full license file "carrot2.LICENSE"
 * in the root folder of the repository checkout or at:
 * http://www.carrot2.org/carrot2.LICENSE
 */

package org.carrot2.source.idol;

import org.carrot2.core.DummyControllerContext;
import org.carrot2.core.ProcessingException;
import org.junit.Test;

/**
 * Basic test cases for {@link OpenSearchDocumentSource}.
 */
public class IdolDocumentSourceTest
{

    @Test
    public void testCorrectConfiguration()
    {
        final IdolDocumentSource source = new IdolDocumentSource();

        source.idolServerName = "localhost";
        source.idolServerPort = 9000;
        source.otherSearchAttributes = "summary=context&amp;combine=simple";
        source.xslTemplateName = "OpenSearchRSS2.0";
        source.minScore = 80;
        source.maximumResults = 1000;
        source.resultsPerPage = 20;

        final DummyControllerContext ctx = new DummyControllerContext();
        source.init(ctx);
        ctx.dispose();
    }
}
