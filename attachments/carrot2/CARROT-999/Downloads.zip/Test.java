package TwoPointOne;

import org.carrot2.source.microsoft.Bing3DocumentSource;

import TwoPointOne.SearchEngines.BingSearch;

public class Test {
	public static void main(String[] args) {
		System.out.println(System
				.getProperty(Bing3DocumentSource.SYSPROP_BING3_API));
		
		SearchEngine searchEngine = new BingSearch();
		SearchResult[] sr = searchEngine.Query("Apple");
		for (int i = 0; i < 10; i++) {
			System.out.println(sr[i].Title);
			System.out.println(sr[i].Url);
		}
		System.out.println(sr.length);
	}
}
