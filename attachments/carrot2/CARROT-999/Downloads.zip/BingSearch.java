package TwoPointOne.SearchEngines;

import java.util.List;
import java.util.Map;

import org.carrot2.core.Controller;
import org.carrot2.core.ControllerFactory;
import org.carrot2.core.Document;
import org.carrot2.core.ProcessingResult;
import org.carrot2.core.attribute.CommonAttributesDescriptor;
import org.carrot2.source.microsoft.Bing3DocumentSource;
import org.carrot2.source.microsoft.Bing3WebDocumentSource;
import org.carrot2.source.microsoft.Bing3WebDocumentSourceDescriptor;

import TwoPointOne.SearchEngine;
import TwoPointOne.SearchResult;

import com.google.common.collect.Maps;

public class BingSearch extends SearchEngine {

	@Override
	public SearchResult[] Query(String query) {
		final Controller controller = ControllerFactory.createSimple();
		final Map<String, Object> attributes = Maps.newHashMap();
		CommonAttributesDescriptor.attributeBuilder(attributes).query(query)
				.results(1000);
		final String key = System
				.getProperty(Bing3DocumentSource.SYSPROP_BING3_API);
		if (key == null) {
			throw new RuntimeException(
					"WARNING! Empty Bing API key,  pass it via -D"
							+ Bing3DocumentSource.SYSPROP_BING3_API + "=...");
		}
		Bing3WebDocumentSourceDescriptor.attributeBuilder(attributes)
				.appid(key);
		final ProcessingResult result = controller.process(attributes,
				Bing3WebDocumentSource.class);
		List<Document> documents = result.getDocuments();
		SearchResult[] ret = new SearchResult[documents.size()];
		for (int i = 0; i < ret.length; i++) {
			Document document = documents.get(i);
			SearchResult searchResult = new SearchResult();
			searchResult.Title = document.getTitle();
			searchResult.Url = document.getContentUrl();
			ret[i] = searchResult;
		}
		return ret;
	}
	
	public static void main(String[] args) {
		BingSearch searchEngine = new BingSearch();
		SearchResult[] sr = searchEngine.Query("Apple");
		for (int i = 0; i < 10; i++) {
			System.out.println(sr[i].Title);
			System.out.println(sr[i].Url);
		}
		System.out.println(sr.length);
	}
	
}
